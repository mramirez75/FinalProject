from tkinter import *
from tkinter import messagebox
import tkinter.font as font
import random
import tkinter as tk

colors = ["Red", "Orange", "White", "Black", "Green", "Blue", "Brown", "Purple", "Yellow", "Pink"]
timer = 60
score = 0
displayed_word_color = ''
#This fuction will be called when start button is clicked
def game():
    def start(): #Once the start button is clicked the game
            #begans and also the timer will start
        global word_color 
        if(timer == 60):
            startCountDown() #Chooses a random color text and word
            word_color = random.choice(colors).lower()
            display_words.config(text=random.choice(colors), fg=word_color)
            color_entry.bind('<Return>', nextWord)#For next color have to press on 'Enter'Key
#This function is to reset the game
    def resetGame():
        global timer, score, word_color #When clicking on reset button then time and score will reset to normal phase
        timer = 60
        score = 0
        word_color = ''
        game_score.config(text = "Your Score : " + str(score))
        display_words.config(text = '')
        time_left.config(text="Game Ends in : -")
        color_entry.delete(0, END)
#This function will start count down
    def startCountDown():
        global timer
        if(timer >= 0):
            time_left.config(text = "Game Ends in : " + str(timer) + "s")
            timer -= 1
            time_left.after(1000,startCountDown)
            if (timer == -1):
                time_left.config(text="Game Over!!!")
#This function to display random words
    def nextWord(event): #When a word is entered it is going to be checked and see it matches with the word in the 'color' dictionary. 
        global word_color
        global score
        if(timer > 0):
            if(word_color == color_entry.get().lower()):
                score += 1
                game_score.config(text = "Your Score : " + str(score))
            color_entry.delete(0, END)
            word_color = random.choice(colors).lower()
            display_words.config(text = random.choice(colors), fg = word_color)
    def leave(): #If the user wishes to leave the game then it gets to click 'quit' button in which will be asked asked again if it wants to leave.

        MsgBox = tk.messagebox.askquestion('Exit','Are you sure you want to exit the application?')
        if MsgBox == 'yes': #If click 'yes' then the window will close
            window.quit()
        else: #If clicked on 'no' then the game will continue
            tk.messagebox.showinfo('Continue','Lets Continue Playing!')

    
  
    window = Tk()
    window.title("Color Game")
    window.geometry("700x500")
#Define image 
    game_desp = "Instruction: Enter the color of the word shown below.\n Press ENTER to start\n DO NOT WRITE THE WORD!"
    game_description = Label(window, text = game_desp, font = "arial 15", fg= "black")
    game_description.pack()
    game_score = Label(window, text = "Your Score : " + str(score), font = (font.Font(size=18)), fg = "green")
    game_score.pack()
    display_words = Label(window , font = (font.Font(size=75)), pady = 15)
    display_words.pack()
    time_left = Label(window, text = "Game Ends in : -", font = (font.Font(size=20)), fg = "black")
    time_left.pack()
    color_entry = Entry(window, width = 35)
    color_entry.pack(pady = 25)
    btn_frame = Frame(window, width= 80, height = 40, bg= 'black')
    btn_frame.pack(side = BOTTOM)
    start_button = Button(btn_frame, text = "Start", width = 20, fg = "black", bg = "pink", bd = 0,padx = 20, pady = 10 , command = start)
    start_button.grid(row=0, column= 0)
    reset_button = Button(btn_frame, text = "Reset", width = 20, fg = "black", bg = "light blue", bd = 0,padx = 20, pady = 10 , command = resetGame)
    reset_button.grid(row=0, column= 1)
    leave_button=Button(btn_frame, text="Quit?", width=22,fg="black", bg="red", bd = 0, padx = 20, pady = 10, command = leave)
    leave_button.grid(row=0, column= 2)
    window.geometry('700x400')
windows=Tk()
windows.geometry("700x400")
x2=Label(windows,text="Let's play a game!", font="times 20")
x2.place(x=40,y=60)
b1=Button(windows, text="Go!", command=game, width=15)
b1.place(x=150, y=100)

windows.mainloop()